set_clock_latency -source -early -min   -5e-05 [get_ports {clk}] -clock clk 
set_clock_latency -source -early -max   -5e-05 [get_ports {clk}] -clock clk 
set_clock_latency -source -late -min   -5e-05 [get_ports {clk}] -clock clk 
set_clock_latency -source -late -max   -5e-05 [get_ports {clk}] -clock clk 
