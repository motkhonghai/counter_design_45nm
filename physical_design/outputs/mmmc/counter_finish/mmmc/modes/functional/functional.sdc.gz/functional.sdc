current_design counter
set_clock_gating_check -rise -setup 0 
set_clock_gating_check -fall -setup 0 
set_units -time 1ns -capacitance 1pf
create_clock [get_ports {clk}]  -name clk -period 10.000000 -waveform {0.000000 5.000000}
set_propagated_clock  [get_clocks {clk}]
set_clock_transition  -rise -min 0.1 [get_clocks {clk}]
set_clock_transition  -rise -max 0.1 [get_clocks {clk}]
set_clock_transition  -fall -min 0.1 [get_clocks {clk}]
set_clock_transition  -fall -max 0.1 [get_clocks {clk}]
set_propagated_clock  [get_ports {clk}]
#END OF CLOCK SECTION#
set_input_delay -add_delay 1 -max -clock [get_clocks {clk}] [get_ports {rst}]
set_output_delay -add_delay 1 -max -clock [get_clocks {clk}] [get_ports {count[7]}]
set_output_delay -add_delay 1 -max -clock [get_clocks {clk}] [get_ports {count[5]}]
set_output_delay -add_delay 1 -max -clock [get_clocks {clk}] [get_ports {count[3]}]
set_output_delay -add_delay 1 -max -clock [get_clocks {clk}] [get_ports {count[1]}]
set_output_delay -add_delay 1 -max -clock [get_clocks {clk}] [get_ports {count[6]}]
set_output_delay -add_delay 1 -max -clock [get_clocks {clk}] [get_ports {count[4]}]
set_output_delay -add_delay 1 -max -clock [get_clocks {clk}] [get_ports {count[2]}]
set_output_delay -add_delay 1 -max -clock [get_clocks {clk}] [get_ports {count[0]}]
set_clock_uncertainty  0.01 [get_ports {clk}]
