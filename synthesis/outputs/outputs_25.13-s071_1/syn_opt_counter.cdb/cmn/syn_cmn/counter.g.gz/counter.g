######################################################################

# Created by Genus(TM) Synthesis Solution 25.13-s071_1 on Wed Sep 09 09:07:45 +07 2026

# This file contains the Genus script for design:counter

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path {. ../}
set_db -quiet hdl_unconnected_marking_done true
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{to_generic 2 284 1 49} {first_condense 1 285 0 50} {PBS_Generic_Opt-Post 3 285 2.9812259999999995 49.979507} {{PBS_Generic-Postgen HBO Optimizations} 0 285 0.0 49.979507} {PBS_TechMap-Start 0 287 0.0 50.979005} {{PBS_TechMap-Premap HBO Optimizations} 0 287 0.0 50.979005} {first_condense 0 287 0 51} {reify 1 288 0 52} {global_incr_map 0 288 0 52} {{PBS_Techmap-Global Mapping} 1 288 0.9588029999999961 51.937808} {{PBS_TechMap-Datapath Postmap Operations} 2 290 2.0 53.937808} {{PBS_TechMap-Postmap HBO Optimizations} 0 290 -0.00027799999999444935 53.93753} {{PBS_TechMap-Postmap Clock Gating} 0 290 0.0 53.93753} {{PBS_TechMap-Postmap Cleanup} 0 290 -0.0005230000000011614 53.937007} {PBS_Techmap-Post_MBCI 0 290 0.0 53.937007} {incr_opt 0 291 0 54} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tim_complex_use_dense false
set_db -quiet tim_complex_use_prevs true
set_db -quiet dft_ignore_segment_mode_name false
set_db -quiet dft_lpc_allow_additional_signal_functions false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_icd1.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet exp_within_stylus_db 1
set_db -quiet script_search_path .
set_db -quiet syn_map_effort medium
set_db -quiet syn_opt_effort medium
set_db -quiet use_area_from_lef true
set_db -quiet shrink_factor 0.9
set_db -quiet read_qrc_tech_file_rc_corner true
set_db -quiet phys_use_segment_parasitics true
set_db -quiet probabilistic_extraction true
set_db -quiet ple_correlation_factors {1.9000 2.0000}
set_db -quiet maximum_interval_of_vias inf
set_db -quiet layer_aware_buffer true
set_db -quiet ple_mode global
::legacy::set_attr -quiet ui_respects_preserve 0 /
::legacy::set_attribute -quiet library_domain library_domain:timing_cond_wcl_slow design:counter
::legacy::set_attr -quiet ui_respects_preserve true /
# BEGIN MSV SECTION
# END MSV SECTION
# BEGIN DFT SECTION
set_db -quiet dft_scan_style muxed_scan
set_db -quiet dft_scanbit_waveform_analysis false
# END DFT SECTION
set_db -quiet design:counter .seq_reason_deleted_internal {}
set_db -quiet design:counter .qos_by_stage {{to_generic {wns 8690} {tns 0} {vep 0} {area 30} {cell_count 26} {utilization  0.00} {runtime 2 284 1 49} }{first_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 35} {cell_count 34} {utilization  0.00} {runtime 1 285 0 50} }{first_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 35} {cell_count 34} {utilization  0.00} {runtime 0 287 0 51} }{reify {wns 8201} {tns 0} {vep 0} {area 18} {cell_count 21} {utilization  0.00} {runtime 1 288 0 52} }{global_incr_map {wns 8206} {tns 0} {vep 0} {area 18} {cell_count 21} {utilization  0.00} {runtime 0 288 0 52} }{incr_opt {wns 214748365} {tns 0} {vep 0} {area 18} {cell_count 20} {utilization  0.00} {runtime 0 291 0 54} }}
set_db -quiet design:counter .seq_mbci_coverage 0.0
set_db -quiet design:counter .stylus_db_state mapped
set_db -quiet design:counter .hdl_filelist {{default -v2001 {SYNTHESIS} {../rtl/counter.v} {. ../rtl} {}}}
set_db -quiet design:counter .hdl_user_name counter
set_db -quiet design:counter .verification_directory fv/counter
set_db -quiet design:counter .arch_filename ../rtl/counter.v
set_db -quiet design:counter .entity_filename ../rtl/counter.v
set_db -quiet port:counter/clk .master_original_name clk
set_db -quiet port:counter/rst .master_original_name rst
set_db -quiet {port:counter/count[7]} .master_original_name count
set_db -quiet {inst:counter/count_reg[7]} .orig_hdl_instantiated false
set_db -quiet {pin:counter/count_reg[7]/Q} .master_original_name {count[7]/q}
set_db -quiet {inst:counter/count_reg[6]} .orig_hdl_instantiated false
set_db -quiet {pin:counter/count_reg[6]/Q} .master_original_name {count[6]/q}
set_db -quiet {inst:counter/count_reg[5]} .orig_hdl_instantiated false
set_db -quiet {pin:counter/count_reg[5]/Q} .master_original_name {count[5]/q}
set_db -quiet {inst:counter/count_reg[4]} .orig_hdl_instantiated false
set_db -quiet {pin:counter/count_reg[4]/Q} .master_original_name {count[4]/q}
set_db -quiet {inst:counter/count_reg[3]} .orig_hdl_instantiated false
set_db -quiet {pin:counter/count_reg[3]/Q} .master_original_name {count[3]/q}
set_db -quiet {inst:counter/count_reg[2]} .orig_hdl_instantiated false
set_db -quiet {pin:counter/count_reg[2]/Q} .master_original_name {count[2]/q}
set_db -quiet {inst:counter/count_reg[1]} .orig_hdl_instantiated false
set_db -quiet {pin:counter/count_reg[1]/Q} .master_original_name {count[1]/q}
set_db -quiet {inst:counter/count_reg[0]} .orig_hdl_instantiated false
set_db -quiet {pin:counter/count_reg[0]/Q} .master_original_name {count[0]/q}
set_db -quiet {pin:counter/count_reg[0]/QN} .master_original_name {count[0]/q}
# BEGIN PMBIST SECTION
# END PMBIST SECTION
# BEGIN PHYSICAL ANNOTATION SECTION
# END PHYSICAL ANNOTATION SECTION
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
