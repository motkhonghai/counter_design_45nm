######################################################################

# Created by Genus(TM) Synthesis Solution 25.13-s071_1 on Wed Sep 09 09:07:45 +07 2026

# This file contains the Genus script for design:counter

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path {. ../}
set_db -quiet hdl_unconnected_marking_done true
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{to_generic 2 284 1 49} {first_condense 1 285 0 50} {PBS_Generic_Opt-Post 3 285 2.9812259999999995 49.979507} {{PBS_Generic-Postgen HBO Optimizations} 0 285 0.0 49.979507} {PBS_TechMap-Start 0 287 0.0 50.979005} {{PBS_TechMap-Premap HBO Optimizations} 0 287 0.0 50.979005} {first_condense 0 287 0 51} {reify 1 288 0 52} {global_incr_map 0 288 0 52} {{PBS_Techmap-Global Mapping} 1 288 0.9588029999999961 51.937808} {{PBS_TechMap-Datapath Postmap Operations} 2 290 2.0 53.937808} {{PBS_TechMap-Postmap HBO Optimizations} 0 290 -0.00027799999999444935 53.93753} {{PBS_TechMap-Postmap Clock Gating} 0 290 0.0 53.93753} {{PBS_TechMap-Postmap Cleanup} 0 290 -0.0005230000000011614 53.937007} {PBS_Techmap-Post_MBCI 0 290 0.0 53.937007} {incr_opt 0 291 0 54} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tim_complex_use_dense false
set_db -quiet tim_complex_use_prevs true
set_db -quiet dft_ignore_segment_mode_name false
set_db -quiet dft_lpc_allow_additional_signal_functions false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_icd1.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet exp_within_stylus_db 1
set_db -quiet script_search_path .
set_db -quiet syn_map_effort medium
set_db -quiet syn_opt_effort medium
set_db -quiet use_area_from_lef true
set_db -quiet shrink_factor 0.9
set_db -quiet read_qrc_tech_file_rc_corner true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
