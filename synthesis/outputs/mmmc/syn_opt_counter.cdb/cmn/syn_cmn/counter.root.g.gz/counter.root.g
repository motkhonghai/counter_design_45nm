######################################################################

# Created by Genus(TM) Synthesis Solution 25.13-s071_1 on Thu Sep 10 10:47:13 +07 2026

# This file contains the Genus script for design:counter

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path /home/icd1/workspace/counter_design_45nm/lib
set_db -quiet set_units_set true
set_db -quiet hdl_unconnected_marking_done true
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{to_generic 2 70 2 52} {first_condense 0 71 0 53} {PBS_Generic_Opt-Post 4 72 2.9799620000000004 52.979299} {{PBS_Generic-Postgen HBO Optimizations} 0 72 1.0 53.979299} {PBS_TechMap-Start 0 74 0.0 54.979052} {{PBS_TechMap-Premap HBO Optimizations} 0 74 0.0 54.979052} {first_condense 1 75 0 56} {reify 1 76 0 57} {global_incr_map 0 76 0 57} {{PBS_Techmap-Global Mapping} 2 76 1.9355499999999992 56.914602} {{PBS_TechMap-Datapath Postmap Operations} 2 78 2.0 58.914602} {{PBS_TechMap-Postmap HBO Optimizations} 0 78 -0.00027700000000407954 58.914325} {{PBS_TechMap-Postmap Clock Gating} 0 78 0.0 58.914325} {{PBS_TechMap-Postmap Cleanup} 0 78 -0.0003509999999948832 58.913974} {PBS_Techmap-Post_MBCI 0 78 0.0 58.913974} {incr_opt 0 79 0 59} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tim_complex_use_dense false
set_db -quiet tim_complex_use_prevs true
set_db -quiet dft_ignore_segment_mode_name false
set_db -quiet dft_lpc_allow_additional_signal_functions false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_icd1.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet exp_within_stylus_db 1
set_db -quiet script_search_path {/home/icd1/workspace/counter_design_45nm/synthesis /home/icd1/workspace/counter_design_45nm}
set_db -quiet syn_map_effort medium
set_db -quiet syn_opt_effort medium
set_db -quiet use_area_from_lef true
set_db -quiet shrink_factor 1.0
set_db -quiet read_qrc_tech_file_rc_corner true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
